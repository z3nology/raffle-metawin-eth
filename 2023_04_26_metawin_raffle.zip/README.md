## Metawin raffle clone
